package ga.framework.operators;

import java.util.List;

import ga.framework.model.Solution;

public interface EvolutionaryOperator {
	public List<Solution> evolvePopulation(List<Solution> population) 
			throws EvolutionException;
}
