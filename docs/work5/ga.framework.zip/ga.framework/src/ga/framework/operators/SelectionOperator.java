package ga.framework.operators;

import java.util.List;

import ga.framework.model.Solution;

public interface SelectionOperator {
	public List<Solution> selectPopulation(List<Solution> candidates, int populationSize);
}
